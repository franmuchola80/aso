#!/bin/bash

# Pedir primer número
read -p "Introduce el primer número: " NUM1

# Pedir segundo número
read -p "Introduce el segundo número: " NUM2

# Mostrar los números introducidos
echo "Primer número: $NUM1"
echo "Segundo número: $NUM2"
